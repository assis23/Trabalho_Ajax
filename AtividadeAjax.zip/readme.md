# Trabalho de SD


1. Abrir arquivo index.html